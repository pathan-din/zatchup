import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-auto-search',
  templateUrl: './auto-search.component.html',
  styleUrls: ['./auto-search.component.css']
})
export class AutoSearchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
