import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-page-not-found',
  templateUrl: './user-page-not-found.component.html',
  styleUrls: ['./user-page-not-found.component.css']
})
export class UserPageNotFoundComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
