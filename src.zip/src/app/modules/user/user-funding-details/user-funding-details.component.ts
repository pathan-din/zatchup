import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-funding-details',
  templateUrl: './user-funding-details.component.html',
  styleUrls: ['./user-funding-details.component.css']
})
export class UserFundingDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
