import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-ei-profile-not-onboard',
  templateUrl: './user-ei-profile-not-onboard.component.html',
  styleUrls: ['./user-ei-profile-not-onboard.component.css']
})
export class UserEiProfileNotOnboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
