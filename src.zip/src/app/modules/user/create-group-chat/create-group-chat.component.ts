import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-group-chat',
  templateUrl: './create-group-chat.component.html',
  styleUrls: ['./create-group-chat.component.css']
})
export class CreateGroupChatComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
