import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-lecture-request',
  templateUrl: './user-lecture-request.component.html',
  styleUrls: ['./user-lecture-request.component.css']
})
export class UserLectureRequestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
