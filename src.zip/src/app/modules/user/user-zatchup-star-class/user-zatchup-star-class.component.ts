import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-zatchup-star-class',
  templateUrl: './user-zatchup-star-class.component.html',
  styleUrls: ['./user-zatchup-star-class.component.css']
})
export class UserZatchupStarClassComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
