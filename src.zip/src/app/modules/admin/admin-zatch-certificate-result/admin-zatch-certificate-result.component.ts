import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-zatch-certificate-result',
  templateUrl: './admin-zatch-certificate-result.component.html',
  styleUrls: ['./admin-zatch-certificate-result.component.css']
})
export class AdminZatchCertificateResultComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
