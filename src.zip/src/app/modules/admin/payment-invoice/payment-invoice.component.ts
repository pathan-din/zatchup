import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment-invoice',
  templateUrl: './payment-invoice.component.html',
  styleUrls: ['./payment-invoice.component.css']
})
export class PaymentInvoiceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
