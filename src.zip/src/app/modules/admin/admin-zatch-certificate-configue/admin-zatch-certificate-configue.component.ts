import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-zatch-certificate-configue',
  templateUrl: './admin-zatch-certificate-configue.component.html',
  styleUrls: ['./admin-zatch-certificate-configue.component.css']
})
export class AdminZatchCertificateConfigueComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
