import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-page-not-found',
  templateUrl: './admin-page-not-found.component.html',
  styleUrls: ['./admin-page-not-found.component.css']
})
export class AdminPageNotFoundComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
