import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ei-page-not-found',
  templateUrl: './ei-page-not-found.component.html',
  styleUrls: ['./ei-page-not-found.component.css']
})
export class EiPageNotFoundComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
