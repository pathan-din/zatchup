import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ei-search',
  templateUrl: './ei-search.component.html',
  styleUrls: ['./ei-search.component.css']
})
export class EiSearchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
