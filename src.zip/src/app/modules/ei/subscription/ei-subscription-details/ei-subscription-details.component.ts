import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ei-subscription-details',
  templateUrl: './ei-subscription-details.component.html',
  styleUrls: ['./ei-subscription-details.component.css']
})
export class EiSubscriptionDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
