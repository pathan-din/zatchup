import { ScrollToBottomDirective } from './scroll-to-bottom.directive';

describe('ScrollToBottomDirective', () => {
  it('should create an instance', () => {
    const directive = new ScrollToBottomDirective();
    expect(directive).toBeTruthy();
  });
});
